--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.5
-- Dumped by pg_dump version 9.6.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE ONLY public.diocese_statistics DROP CONSTRAINT diocese_statistics_diocese_id_da33a661_fk_diocese_diocese_id;
ALTER TABLE ONLY public.diocese_priest DROP CONSTRAINT diocese_priest_order_id_ed69b87b_fk_diocese_order_id;
ALTER TABLE ONLY public.diocese_priest DROP CONSTRAINT diocese_priest_diocese_id_36f67745_fk_diocese_diocese_id;
ALTER TABLE ONLY public.diocese_priest DROP CONSTRAINT diocese_priest_archdiocese_id_76cf1b1f_fk_diocese_a;
ALTER TABLE ONLY public.diocese_dioceseassignment DROP CONSTRAINT diocese_dioceseassig_diocese_id_aa18c13a_fk_diocese_d;
ALTER TABLE ONLY public.diocese_dioceseassignment DROP CONSTRAINT diocese_dioceseassig_archdiocese_id_dd052bd8_fk_diocese_a;
ALTER TABLE ONLY public.diocese_diocese DROP CONSTRAINT diocese_diocese_created_from_id_7e175365_fk_diocese_diocese_id;
ALTER TABLE ONLY public.diocese_diocese DROP CONSTRAINT diocese_diocese_archdiocese_id_fef0b655_fk_diocese_a;
ALTER TABLE ONLY public.diocese_churchassignment DROP CONSTRAINT diocese_churchassign_diocese_church_id_40858a0b_fk_diocese_c;
ALTER TABLE ONLY public.diocese_churchassignment DROP CONSTRAINT diocese_churchassign_archdiocese_church_i_1abd63a9_fk_diocese_a;
ALTER TABLE ONLY public.diocese_church DROP CONSTRAINT diocese_church_diocese_id_aacd45eb_fk_diocese_diocese_id;
ALTER TABLE ONLY public.diocese_archdiocesechurch DROP CONSTRAINT diocese_archdiocesec_diocese_id_1a31fab8_fk_diocese_a;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_expire_date_a5c62663;
DROP INDEX public.django_admin_log_user_id_c564eba6;
DROP INDEX public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX public.diocese_statistics_diocese_id_da33a661;
DROP INDEX public.diocese_priest_order_id_ed69b87b;
DROP INDEX public.diocese_priest_diocese_id_36f67745;
DROP INDEX public.diocese_priest_archdiocese_id_76cf1b1f;
DROP INDEX public.diocese_dioceseassignment_diocese_id_aa18c13a;
DROP INDEX public.diocese_dioceseassignment_archdiocese_id_dd052bd8;
DROP INDEX public.diocese_diocese_created_from_id_7e175365;
DROP INDEX public.diocese_diocese_archdiocese_id_fef0b655;
DROP INDEX public.diocese_churchassignment_diocese_church_id_40858a0b;
DROP INDEX public.diocese_churchassignment_archdiocese_church_id_1abd63a9;
DROP INDEX public.diocese_church_diocese_id_aacd45eb;
DROP INDEX public.diocese_archdiocesechurch_diocese_id_1a31fab8;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX public.auth_user_groups_group_id_97559544;
DROP INDEX public.auth_permission_content_type_id_2f476e4b;
DROP INDEX public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.diocese_statistics DROP CONSTRAINT diocese_statistics_pkey;
ALTER TABLE ONLY public.diocese_priest DROP CONSTRAINT diocese_priest_pkey;
ALTER TABLE ONLY public.diocese_order DROP CONSTRAINT diocese_order_pkey;
ALTER TABLE ONLY public.diocese_dioceseassignment DROP CONSTRAINT diocese_dioceseassignment_pkey;
ALTER TABLE ONLY public.diocese_diocese DROP CONSTRAINT diocese_diocese_pkey;
ALTER TABLE ONLY public.diocese_deacon DROP CONSTRAINT diocese_deacon_pkey;
ALTER TABLE ONLY public.diocese_churchassignment DROP CONSTRAINT diocese_churchassignment_pkey;
ALTER TABLE ONLY public.diocese_church DROP CONSTRAINT diocese_church_pkey;
ALTER TABLE ONLY public.diocese_church DROP CONSTRAINT diocese_church_name_city_5aae268a_uniq;
ALTER TABLE ONLY public.diocese_archdiocesechurch DROP CONSTRAINT diocese_archdiocesechurch_pkey;
ALTER TABLE ONLY public.diocese_archdiocesechurch DROP CONSTRAINT diocese_archdiocesechurch_name_city_0b67df14_uniq;
ALTER TABLE ONLY public.diocese_archdiocese DROP CONSTRAINT diocese_archdiocese_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_statistics ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_priest ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_order ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_dioceseassignment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_diocese ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_deacon ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_churchassignment ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_church ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_archdiocesechurch ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.diocese_archdiocese ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.diocese_statistics_id_seq;
DROP TABLE public.diocese_statistics;
DROP SEQUENCE public.diocese_priest_id_seq;
DROP TABLE public.diocese_priest;
DROP SEQUENCE public.diocese_order_id_seq;
DROP TABLE public.diocese_order;
DROP SEQUENCE public.diocese_dioceseassignment_id_seq;
DROP TABLE public.diocese_dioceseassignment;
DROP SEQUENCE public.diocese_diocese_id_seq;
DROP TABLE public.diocese_diocese;
DROP SEQUENCE public.diocese_deacon_id_seq;
DROP TABLE public.diocese_deacon;
DROP SEQUENCE public.diocese_churchassignment_id_seq;
DROP TABLE public.diocese_churchassignment;
DROP SEQUENCE public.diocese_church_id_seq;
DROP TABLE public.diocese_church;
DROP SEQUENCE public.diocese_archdiocesechurch_id_seq;
DROP TABLE public.diocese_archdiocesechurch;
DROP SEQUENCE public.diocese_archdiocese_id_seq;
DROP TABLE public.diocese_archdiocese;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO rccdbuser;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO rccdbuser;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO rccdbuser;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO rccdbuser;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO rccdbuser;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO rccdbuser;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO rccdbuser;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO rccdbuser;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO rccdbuser;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO rccdbuser;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO rccdbuser;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO rccdbuser;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: diocese_archdiocese; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_archdiocese (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    city character varying(200) NOT NULL,
    state character varying(200) NOT NULL,
    mother_church_name character varying(200) NOT NULL,
    mother_church_address character varying(200) NOT NULL,
    mother_church_zipcode character varying(200) NOT NULL,
    establish_date date NOT NULL
);


ALTER TABLE diocese_archdiocese OWNER TO rccdbuser;

--
-- Name: diocese_archdiocese_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_archdiocese_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_archdiocese_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_archdiocese_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_archdiocese_id_seq OWNED BY diocese_archdiocese.id;


--
-- Name: diocese_archdiocesechurch; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_archdiocesechurch (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(200) NOT NULL,
    zipcode character varying(200) NOT NULL,
    lat character varying(200),
    lon character varying(200),
    city character varying(200) NOT NULL,
    state character varying(200) NOT NULL,
    establish_date date NOT NULL,
    diocese_id integer NOT NULL
);


ALTER TABLE diocese_archdiocesechurch OWNER TO rccdbuser;

--
-- Name: diocese_archdiocesechurch_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_archdiocesechurch_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_archdiocesechurch_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_archdiocesechurch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_archdiocesechurch_id_seq OWNED BY diocese_archdiocesechurch.id;


--
-- Name: diocese_church; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_church (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    address character varying(200),
    zipcode character varying(200),
    lat character varying(200),
    lon character varying(200),
    city character varying(200) NOT NULL,
    state character varying(200) NOT NULL,
    establish_date date NOT NULL,
    diocese_id integer NOT NULL,
    county character varying(200)
);


ALTER TABLE diocese_church OWNER TO rccdbuser;

--
-- Name: diocese_church_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_church_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_church_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_church_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_church_id_seq OWNED BY diocese_church.id;


--
-- Name: diocese_churchassignment; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_churchassignment (
    id integer NOT NULL,
    start_date date,
    end_date date,
    archdiocese_church_id integer,
    diocese_church_id integer
);


ALTER TABLE diocese_churchassignment OWNER TO rccdbuser;

--
-- Name: diocese_churchassignment_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_churchassignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_churchassignment_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_churchassignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_churchassignment_id_seq OWNED BY diocese_churchassignment.id;


--
-- Name: diocese_deacon; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_deacon (
    id integer NOT NULL,
    first_name character varying(200) NOT NULL,
    middle_name character varying(200) NOT NULL,
    last_name character varying(200) NOT NULL,
    year_born character varying(4),
    year_ordained character varying(4),
    priest boolean NOT NULL,
    order_priest boolean NOT NULL
);


ALTER TABLE diocese_deacon OWNER TO rccdbuser;

--
-- Name: diocese_deacon_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_deacon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_deacon_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_deacon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_deacon_id_seq OWNED BY diocese_deacon.id;


--
-- Name: diocese_diocese; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_diocese (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    city character varying(200) NOT NULL,
    state character varying(200) NOT NULL,
    establish_date date NOT NULL,
    archdiocese_id integer NOT NULL,
    created_from_id integer
);


ALTER TABLE diocese_diocese OWNER TO rccdbuser;

--
-- Name: diocese_diocese_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_diocese_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_diocese_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_diocese_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_diocese_id_seq OWNED BY diocese_diocese.id;


--
-- Name: diocese_dioceseassignment; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_dioceseassignment (
    id integer NOT NULL,
    "position" character varying(10) NOT NULL,
    start_date date,
    end_date date,
    archdiocese_id integer,
    diocese_id integer
);


ALTER TABLE diocese_dioceseassignment OWNER TO rccdbuser;

--
-- Name: diocese_dioceseassignment_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_dioceseassignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_dioceseassignment_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_dioceseassignment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_dioceseassignment_id_seq OWNED BY diocese_dioceseassignment.id;


--
-- Name: diocese_order; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_order (
    id integer NOT NULL,
    order_name character varying(230) NOT NULL,
    order_abbreviation character varying(30) NOT NULL,
    order_priest boolean NOT NULL,
    order_family character varying(50),
    order_founder character varying(230),
    order_founding_year character varying(4)
);


ALTER TABLE diocese_order OWNER TO rccdbuser;

--
-- Name: diocese_order_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_order_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_order_id_seq OWNED BY diocese_order.id;


--
-- Name: diocese_priest; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_priest (
    id integer NOT NULL,
    first_name character varying(30) NOT NULL,
    middle_name character varying(30),
    last_name character varying(30) NOT NULL,
    year_born character varying(4),
    order_priest boolean NOT NULL,
    offender boolean NOT NULL,
    year_ordained character varying(16),
    notes character varying(5000) NOT NULL,
    archdiocese_id integer,
    diocese_id integer,
    order_id integer,
    clergy_type character varying(1) NOT NULL
);


ALTER TABLE diocese_priest OWNER TO rccdbuser;

--
-- Name: diocese_priest_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_priest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_priest_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_priest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_priest_id_seq OWNED BY diocese_priest.id;


--
-- Name: diocese_statistics; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE diocese_statistics (
    id integer NOT NULL,
    year smallint NOT NULL,
    total_priests smallint NOT NULL,
    num_parishes smallint NOT NULL,
    diocese_id integer NOT NULL,
    CONSTRAINT diocese_statistics_num_parishes_check CHECK ((num_parishes >= 0)),
    CONSTRAINT diocese_statistics_total_priests_check CHECK ((total_priests >= 0)),
    CONSTRAINT diocese_statistics_year_check CHECK ((year >= 0))
);


ALTER TABLE diocese_statistics OWNER TO rccdbuser;

--
-- Name: diocese_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE diocese_statistics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE diocese_statistics_id_seq OWNER TO rccdbuser;

--
-- Name: diocese_statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE diocese_statistics_id_seq OWNED BY diocese_statistics.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO rccdbuser;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO rccdbuser;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO rccdbuser;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO rccdbuser;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO rccdbuser;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: rccdbuser
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO rccdbuser;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rccdbuser
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: rccdbuser
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO rccdbuser;

--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: diocese_archdiocese id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_archdiocese ALTER COLUMN id SET DEFAULT nextval('diocese_archdiocese_id_seq'::regclass);


--
-- Name: diocese_archdiocesechurch id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_archdiocesechurch ALTER COLUMN id SET DEFAULT nextval('diocese_archdiocesechurch_id_seq'::regclass);


--
-- Name: diocese_church id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_church ALTER COLUMN id SET DEFAULT nextval('diocese_church_id_seq'::regclass);


--
-- Name: diocese_churchassignment id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_churchassignment ALTER COLUMN id SET DEFAULT nextval('diocese_churchassignment_id_seq'::regclass);


--
-- Name: diocese_deacon id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_deacon ALTER COLUMN id SET DEFAULT nextval('diocese_deacon_id_seq'::regclass);


--
-- Name: diocese_diocese id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_diocese ALTER COLUMN id SET DEFAULT nextval('diocese_diocese_id_seq'::regclass);


--
-- Name: diocese_dioceseassignment id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_dioceseassignment ALTER COLUMN id SET DEFAULT nextval('diocese_dioceseassignment_id_seq'::regclass);


--
-- Name: diocese_order id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_order ALTER COLUMN id SET DEFAULT nextval('diocese_order_id_seq'::regclass);


--
-- Name: diocese_priest id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_priest ALTER COLUMN id SET DEFAULT nextval('diocese_priest_id_seq'::regclass);


--
-- Name: diocese_statistics id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_statistics ALTER COLUMN id SET DEFAULT nextval('diocese_statistics_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY auth_group (id, name) FROM stdin;
\.
COPY auth_group (id, name) FROM '$$PATH$$/2375.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2377.dat';

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2373.dat';

--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('auth_permission_id_seq', 48, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/2379.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/2381.dat';

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2383.dat';

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: diocese_archdiocese; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_archdiocese (id, name, city, state, mother_church_name, mother_church_address, mother_church_zipcode, establish_date) FROM stdin;
\.
COPY diocese_archdiocese (id, name, city, state, mother_church_name, mother_church_address, mother_church_zipcode, establish_date) FROM '$$PATH$$/2388.dat';

--
-- Name: diocese_archdiocese_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_archdiocese_id_seq', 37, true);


--
-- Data for Name: diocese_archdiocesechurch; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_archdiocesechurch (id, name, address, zipcode, lat, lon, city, state, establish_date, diocese_id) FROM stdin;
\.
COPY diocese_archdiocesechurch (id, name, address, zipcode, lat, lon, city, state, establish_date, diocese_id) FROM '$$PATH$$/2394.dat';

--
-- Name: diocese_archdiocesechurch_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_archdiocesechurch_id_seq', 1, false);


--
-- Data for Name: diocese_church; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_church (id, name, address, zipcode, lat, lon, city, state, establish_date, diocese_id, county) FROM stdin;
\.
COPY diocese_church (id, name, address, zipcode, lat, lon, city, state, establish_date, diocese_id, county) FROM '$$PATH$$/2396.dat';

--
-- Name: diocese_church_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_church_id_seq', 1, false);


--
-- Data for Name: diocese_churchassignment; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_churchassignment (id, start_date, end_date, archdiocese_church_id, diocese_church_id) FROM stdin;
\.
COPY diocese_churchassignment (id, start_date, end_date, archdiocese_church_id, diocese_church_id) FROM '$$PATH$$/2398.dat';

--
-- Name: diocese_churchassignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_churchassignment_id_seq', 1, false);


--
-- Data for Name: diocese_deacon; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_deacon (id, first_name, middle_name, last_name, year_born, year_ordained, priest, order_priest) FROM stdin;
\.
COPY diocese_deacon (id, first_name, middle_name, last_name, year_born, year_ordained, priest, order_priest) FROM '$$PATH$$/2400.dat';

--
-- Name: diocese_deacon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_deacon_id_seq', 1, false);


--
-- Data for Name: diocese_diocese; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_diocese (id, name, city, state, establish_date, archdiocese_id, created_from_id) FROM stdin;
\.
COPY diocese_diocese (id, name, city, state, establish_date, archdiocese_id, created_from_id) FROM '$$PATH$$/2390.dat';

--
-- Name: diocese_diocese_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_diocese_id_seq', 432, true);


--
-- Data for Name: diocese_dioceseassignment; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_dioceseassignment (id, "position", start_date, end_date, archdiocese_id, diocese_id) FROM stdin;
\.
COPY diocese_dioceseassignment (id, "position", start_date, end_date, archdiocese_id, diocese_id) FROM '$$PATH$$/2402.dat';

--
-- Name: diocese_dioceseassignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_dioceseassignment_id_seq', 1, false);


--
-- Data for Name: diocese_order; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_order (id, order_name, order_abbreviation, order_priest, order_family, order_founder, order_founding_year) FROM stdin;
\.
COPY diocese_order (id, order_name, order_abbreviation, order_priest, order_family, order_founder, order_founding_year) FROM '$$PATH$$/2406.dat';

--
-- Name: diocese_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_order_id_seq', 3404, true);


--
-- Data for Name: diocese_priest; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_priest (id, first_name, middle_name, last_name, year_born, order_priest, offender, year_ordained, notes, archdiocese_id, diocese_id, order_id, clergy_type) FROM stdin;
\.
COPY diocese_priest (id, first_name, middle_name, last_name, year_born, order_priest, offender, year_ordained, notes, archdiocese_id, diocese_id, order_id, clergy_type) FROM '$$PATH$$/2404.dat';

--
-- Name: diocese_priest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_priest_id_seq', 18882, true);


--
-- Data for Name: diocese_statistics; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY diocese_statistics (id, year, total_priests, num_parishes, diocese_id) FROM stdin;
\.
COPY diocese_statistics (id, year, total_priests, num_parishes, diocese_id) FROM '$$PATH$$/2392.dat';

--
-- Name: diocese_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('diocese_statistics_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2385.dat';

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 11109, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY django_content_type (id, app_label, model) FROM stdin;
\.
COPY django_content_type (id, app_label, model) FROM '$$PATH$$/2371.dat';

--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('django_content_type_id_seq', 16, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY django_migrations (id, app, name, applied) FROM stdin;
\.
COPY django_migrations (id, app, name, applied) FROM '$$PATH$$/2369.dat';

--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rccdbuser
--

SELECT pg_catalog.setval('django_migrations_id_seq', 28, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: rccdbuser
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2386.dat';

--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: diocese_archdiocese diocese_archdiocese_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_archdiocese
    ADD CONSTRAINT diocese_archdiocese_pkey PRIMARY KEY (id);


--
-- Name: diocese_archdiocesechurch diocese_archdiocesechurch_name_city_0b67df14_uniq; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_archdiocesechurch
    ADD CONSTRAINT diocese_archdiocesechurch_name_city_0b67df14_uniq UNIQUE (name, city);


--
-- Name: diocese_archdiocesechurch diocese_archdiocesechurch_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_archdiocesechurch
    ADD CONSTRAINT diocese_archdiocesechurch_pkey PRIMARY KEY (id);


--
-- Name: diocese_church diocese_church_name_city_5aae268a_uniq; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_church
    ADD CONSTRAINT diocese_church_name_city_5aae268a_uniq UNIQUE (name, city);


--
-- Name: diocese_church diocese_church_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_church
    ADD CONSTRAINT diocese_church_pkey PRIMARY KEY (id);


--
-- Name: diocese_churchassignment diocese_churchassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_churchassignment
    ADD CONSTRAINT diocese_churchassignment_pkey PRIMARY KEY (id);


--
-- Name: diocese_deacon diocese_deacon_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_deacon
    ADD CONSTRAINT diocese_deacon_pkey PRIMARY KEY (id);


--
-- Name: diocese_diocese diocese_diocese_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_diocese
    ADD CONSTRAINT diocese_diocese_pkey PRIMARY KEY (id);


--
-- Name: diocese_dioceseassignment diocese_dioceseassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_dioceseassignment
    ADD CONSTRAINT diocese_dioceseassignment_pkey PRIMARY KEY (id);


--
-- Name: diocese_order diocese_order_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_order
    ADD CONSTRAINT diocese_order_pkey PRIMARY KEY (id);


--
-- Name: diocese_priest diocese_priest_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_priest
    ADD CONSTRAINT diocese_priest_pkey PRIMARY KEY (id);


--
-- Name: diocese_statistics diocese_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_statistics
    ADD CONSTRAINT diocese_statistics_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_user_groups_group_id_97559544 ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX auth_user_username_6821ab7c_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: diocese_archdiocesechurch_diocese_id_1a31fab8; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_archdiocesechurch_diocese_id_1a31fab8 ON diocese_archdiocesechurch USING btree (diocese_id);


--
-- Name: diocese_church_diocese_id_aacd45eb; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_church_diocese_id_aacd45eb ON diocese_church USING btree (diocese_id);


--
-- Name: diocese_churchassignment_archdiocese_church_id_1abd63a9; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_churchassignment_archdiocese_church_id_1abd63a9 ON diocese_churchassignment USING btree (archdiocese_church_id);


--
-- Name: diocese_churchassignment_diocese_church_id_40858a0b; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_churchassignment_diocese_church_id_40858a0b ON diocese_churchassignment USING btree (diocese_church_id);


--
-- Name: diocese_diocese_archdiocese_id_fef0b655; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_diocese_archdiocese_id_fef0b655 ON diocese_diocese USING btree (archdiocese_id);


--
-- Name: diocese_diocese_created_from_id_7e175365; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_diocese_created_from_id_7e175365 ON diocese_diocese USING btree (created_from_id);


--
-- Name: diocese_dioceseassignment_archdiocese_id_dd052bd8; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_dioceseassignment_archdiocese_id_dd052bd8 ON diocese_dioceseassignment USING btree (archdiocese_id);


--
-- Name: diocese_dioceseassignment_diocese_id_aa18c13a; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_dioceseassignment_diocese_id_aa18c13a ON diocese_dioceseassignment USING btree (diocese_id);


--
-- Name: diocese_priest_archdiocese_id_76cf1b1f; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_priest_archdiocese_id_76cf1b1f ON diocese_priest USING btree (archdiocese_id);


--
-- Name: diocese_priest_diocese_id_36f67745; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_priest_diocese_id_36f67745 ON diocese_priest USING btree (diocese_id);


--
-- Name: diocese_priest_order_id_ed69b87b; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_priest_order_id_ed69b87b ON diocese_priest USING btree (order_id);


--
-- Name: diocese_statistics_diocese_id_da33a661; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX diocese_statistics_diocese_id_da33a661 ON diocese_statistics USING btree (diocese_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX django_session_expire_date_a5c62663 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: rccdbuser
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_archdiocesechurch diocese_archdiocesec_diocese_id_1a31fab8_fk_diocese_a; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_archdiocesechurch
    ADD CONSTRAINT diocese_archdiocesec_diocese_id_1a31fab8_fk_diocese_a FOREIGN KEY (diocese_id) REFERENCES diocese_archdiocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_church diocese_church_diocese_id_aacd45eb_fk_diocese_diocese_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_church
    ADD CONSTRAINT diocese_church_diocese_id_aacd45eb_fk_diocese_diocese_id FOREIGN KEY (diocese_id) REFERENCES diocese_diocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_churchassignment diocese_churchassign_archdiocese_church_i_1abd63a9_fk_diocese_a; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_churchassignment
    ADD CONSTRAINT diocese_churchassign_archdiocese_church_i_1abd63a9_fk_diocese_a FOREIGN KEY (archdiocese_church_id) REFERENCES diocese_archdiocesechurch(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_churchassignment diocese_churchassign_diocese_church_id_40858a0b_fk_diocese_c; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_churchassignment
    ADD CONSTRAINT diocese_churchassign_diocese_church_id_40858a0b_fk_diocese_c FOREIGN KEY (diocese_church_id) REFERENCES diocese_church(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_diocese diocese_diocese_archdiocese_id_fef0b655_fk_diocese_a; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_diocese
    ADD CONSTRAINT diocese_diocese_archdiocese_id_fef0b655_fk_diocese_a FOREIGN KEY (archdiocese_id) REFERENCES diocese_archdiocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_diocese diocese_diocese_created_from_id_7e175365_fk_diocese_diocese_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_diocese
    ADD CONSTRAINT diocese_diocese_created_from_id_7e175365_fk_diocese_diocese_id FOREIGN KEY (created_from_id) REFERENCES diocese_diocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_dioceseassignment diocese_dioceseassig_archdiocese_id_dd052bd8_fk_diocese_a; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_dioceseassignment
    ADD CONSTRAINT diocese_dioceseassig_archdiocese_id_dd052bd8_fk_diocese_a FOREIGN KEY (archdiocese_id) REFERENCES diocese_archdiocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_dioceseassignment diocese_dioceseassig_diocese_id_aa18c13a_fk_diocese_d; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_dioceseassignment
    ADD CONSTRAINT diocese_dioceseassig_diocese_id_aa18c13a_fk_diocese_d FOREIGN KEY (diocese_id) REFERENCES diocese_diocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_priest diocese_priest_archdiocese_id_76cf1b1f_fk_diocese_a; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_priest
    ADD CONSTRAINT diocese_priest_archdiocese_id_76cf1b1f_fk_diocese_a FOREIGN KEY (archdiocese_id) REFERENCES diocese_archdiocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_priest diocese_priest_diocese_id_36f67745_fk_diocese_diocese_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_priest
    ADD CONSTRAINT diocese_priest_diocese_id_36f67745_fk_diocese_diocese_id FOREIGN KEY (diocese_id) REFERENCES diocese_diocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_priest diocese_priest_order_id_ed69b87b_fk_diocese_order_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_priest
    ADD CONSTRAINT diocese_priest_order_id_ed69b87b_fk_diocese_order_id FOREIGN KEY (order_id) REFERENCES diocese_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: diocese_statistics diocese_statistics_diocese_id_da33a661_fk_diocese_diocese_id; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY diocese_statistics
    ADD CONSTRAINT diocese_statistics_diocese_id_da33a661_fk_diocese_diocese_id FOREIGN KEY (diocese_id) REFERENCES diocese_diocese(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk; Type: FK CONSTRAINT; Schema: public; Owner: rccdbuser
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

